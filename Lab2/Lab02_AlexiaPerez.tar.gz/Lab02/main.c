#include <stdio.h>

extern long long int test();                  
extern long long int lab02b();                
extern void lab02c(long long int a);          // Comment out until Demo 2
extern long long int lab02d(long long int b); // Comment out until Demo 3

int main(void)
{
        test();      // Given code
	lab02b();    // Demo 1
	lab02c(200); // Demo 2

	printf("Test 1 is: %lld\n", test());             // Test 1
	printf("Demo 1 result is: %lld\n", lab02b());    // Demo 1
 
	long long int b = lab02d(1);                     // Demo 3 
	printf("Demo 3 result is = %lld\n", b);          // Demo 3

        return 0;
}
